# How to Contribute

Read the [how to contribute guidelines](http://docs.ampligraph.org/en/latest/dev.html).