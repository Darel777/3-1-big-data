load_from_rdf
=================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_from_rdf
