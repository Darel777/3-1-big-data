RandomUniform
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: RandomUniform

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RandomUniform.__init__
   
   .. automethod:: RandomUniform.__init__
   
   
