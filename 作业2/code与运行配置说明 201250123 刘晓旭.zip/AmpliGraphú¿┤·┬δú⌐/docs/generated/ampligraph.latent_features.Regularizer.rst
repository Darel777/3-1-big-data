Regularizer
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: Regularizer

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Regularizer.__init__
      ~Regularizer.get_state
      ~Regularizer._init_hyperparams
      ~Regularizer.apply
      ~Regularizer._apply
   
   .. automethod:: Regularizer.__init__
   .. automethod:: Regularizer.get_state
   .. automethod:: Regularizer._init_hyperparams
   .. automethod:: Regularizer.apply
   .. automethod:: Regularizer._apply
   
   
