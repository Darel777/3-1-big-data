Loss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: Loss

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Loss.__init__
      ~Loss.get_state
      ~Loss._init_hyperparams
      ~Loss._inputs_check
      ~Loss.apply
      ~Loss._apply
   
   .. automethod:: Loss.__init__
   .. automethod:: Loss.get_state
   .. automethod:: Loss._init_hyperparams
   .. automethod:: Loss._inputs_check
   .. automethod:: Loss.apply
   .. automethod:: Loss._apply
   
   
