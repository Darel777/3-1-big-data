evaluate_performance
==========================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: evaluate_performance
