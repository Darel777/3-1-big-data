SGDOptimizer
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: SGDOptimizer

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SGDOptimizer.__init__
      ~SGDOptimizer.minimize
      ~SGDOptimizer.update_feed_dict
   
   .. automethod:: SGDOptimizer.__init__
   .. automethod:: SGDOptimizer.minimize
   .. automethod:: SGDOptimizer.update_feed_dict
   
   
