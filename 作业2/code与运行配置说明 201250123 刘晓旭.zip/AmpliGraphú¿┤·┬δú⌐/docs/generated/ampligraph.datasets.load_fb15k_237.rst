load_fb15k_237
==================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_fb15k_237
