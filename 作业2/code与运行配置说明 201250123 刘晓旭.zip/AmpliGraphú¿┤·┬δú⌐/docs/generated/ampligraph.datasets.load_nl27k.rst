load_nl27k
==============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_nl27k
