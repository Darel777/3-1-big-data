ConvE
================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: ConvE

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ConvE.__init__
      ~ConvE.fit
      ~ConvE.get_embeddings
      ~ConvE.get_hyperparameter_dict
      ~ConvE.predict
      ~ConvE.calibrate
      ~ConvE.predict_proba

   .. automethod:: ConvE.__init__
   .. automethod:: ConvE.fit
   .. automethod:: ConvE.get_embeddings
   .. automethod:: ConvE.get_hyperparameter_dict
   .. automethod:: ConvE.predict
   .. automethod:: ConvE.calibrate
   .. automethod:: ConvE.predict_proba
   
   


