generate_corruptions_for_fit
==================================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: generate_corruptions_for_fit
