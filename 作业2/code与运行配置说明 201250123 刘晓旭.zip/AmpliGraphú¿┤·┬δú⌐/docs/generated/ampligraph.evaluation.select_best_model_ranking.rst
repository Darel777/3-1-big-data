select_best_model_ranking
===============================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: select_best_model_ranking
