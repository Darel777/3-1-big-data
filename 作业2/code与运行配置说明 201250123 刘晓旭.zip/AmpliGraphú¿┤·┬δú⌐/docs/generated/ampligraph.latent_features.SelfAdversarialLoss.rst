SelfAdversarialLoss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: SelfAdversarialLoss

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SelfAdversarialLoss.__init__
   
   .. automethod:: SelfAdversarialLoss.__init__
   
   
