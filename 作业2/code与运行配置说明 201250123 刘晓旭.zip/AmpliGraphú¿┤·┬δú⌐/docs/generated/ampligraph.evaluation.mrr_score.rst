mrr_score
===============================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: mrr_score
