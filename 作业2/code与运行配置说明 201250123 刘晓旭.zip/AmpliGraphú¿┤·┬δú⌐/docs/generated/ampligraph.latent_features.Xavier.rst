Xavier
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: Xavier

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Xavier.__init__
   
   .. automethod:: Xavier.__init__
   
   
