RandomBaseline
=========================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: RandomBaseline

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RandomBaseline.__init__
      ~RandomBaseline.fit
      ~RandomBaseline.predict
      ~RandomBaseline.get_hyperparameter_dict
   
   .. automethod:: RandomBaseline.__init__
   .. automethod:: RandomBaseline.fit
   .. automethod:: RandomBaseline.predict
   .. automethod:: RandomBaseline.get_hyperparameter_dict
   
   


