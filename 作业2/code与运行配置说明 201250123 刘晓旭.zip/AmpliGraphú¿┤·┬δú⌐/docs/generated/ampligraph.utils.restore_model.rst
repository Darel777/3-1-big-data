restore_model
==============================

.. currentmodule:: ampligraph.utils

.. autofunction:: restore_model
