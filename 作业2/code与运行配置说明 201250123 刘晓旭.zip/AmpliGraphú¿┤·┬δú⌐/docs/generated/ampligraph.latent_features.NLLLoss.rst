NLLLoss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: NLLLoss

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NLLLoss.__init__
   
   .. automethod:: NLLLoss.__init__
   
   