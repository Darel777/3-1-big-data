find_clusters
==================================

.. currentmodule:: ampligraph.discovery

.. autofunction:: find_clusters
