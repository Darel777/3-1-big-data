MomentumOptimizer
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: MomentumOptimizer

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MomentumOptimizer.__init__
      ~MomentumOptimizer.minimize
      ~MomentumOptimizer.update_feed_dict
   
   .. automethod:: MomentumOptimizer.__init__
   .. automethod:: MomentumOptimizer.minimize
   .. automethod:: MomentumOptimizer.update_feed_dict
   
   
