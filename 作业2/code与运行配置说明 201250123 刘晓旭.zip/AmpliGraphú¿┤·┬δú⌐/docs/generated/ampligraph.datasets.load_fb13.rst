load_fb13
=============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_fb13
