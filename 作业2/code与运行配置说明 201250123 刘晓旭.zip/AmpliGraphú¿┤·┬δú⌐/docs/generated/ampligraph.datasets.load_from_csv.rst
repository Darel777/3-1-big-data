load_from_csv
=================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_from_csv
