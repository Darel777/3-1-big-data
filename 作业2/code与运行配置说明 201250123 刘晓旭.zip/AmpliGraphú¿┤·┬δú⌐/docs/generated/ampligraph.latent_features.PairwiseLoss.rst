PairwiseLoss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: PairwiseLoss

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PairwiseLoss.__init__
   
   .. automethod:: PairwiseLoss.__init__
   
   
