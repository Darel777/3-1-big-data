LPRegularizer
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: LPRegularizer

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LPRegularizer.__init__
   
   .. automethod:: LPRegularizer.__init__
   
   
