generate_corruptions_for_eval
===================================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: generate_corruptions_for_eval
