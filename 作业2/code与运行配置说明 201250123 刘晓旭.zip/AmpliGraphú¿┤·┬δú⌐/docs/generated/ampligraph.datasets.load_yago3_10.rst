load_yago3_10
=================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_yago3_10
