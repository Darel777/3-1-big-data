load_onet20k
================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_onet20k
