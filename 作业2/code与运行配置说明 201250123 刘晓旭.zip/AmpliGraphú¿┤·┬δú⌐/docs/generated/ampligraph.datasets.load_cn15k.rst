load_cn15k
==============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_cn15k
