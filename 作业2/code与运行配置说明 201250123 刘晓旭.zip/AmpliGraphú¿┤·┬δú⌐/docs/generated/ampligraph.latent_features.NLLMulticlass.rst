NLLMulticlass
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: NLLMulticlass

   
   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NLLMulticlass.__init__
   
   .. automethod:: NLLMulticlass.__init__
   
   