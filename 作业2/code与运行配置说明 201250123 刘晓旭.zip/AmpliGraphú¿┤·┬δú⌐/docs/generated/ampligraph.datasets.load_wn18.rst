load_wn18
=============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_wn18
