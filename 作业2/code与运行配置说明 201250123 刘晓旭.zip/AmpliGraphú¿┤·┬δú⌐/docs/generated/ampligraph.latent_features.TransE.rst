TransE
=================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: TransE

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TransE.__init__
      ~TransE.fit
      ~TransE.get_embeddings
      ~TransE.get_hyperparameter_dict
      ~TransE.predict
      ~TransE.calibrate
      ~TransE.predict_proba

   .. automethod:: TransE.__init__
   .. automethod:: TransE.fit
   .. automethod:: TransE.get_embeddings
   .. automethod:: TransE.get_hyperparameter_dict
   .. automethod:: TransE.predict
   .. automethod:: TransE.calibrate
   .. automethod:: TransE.predict_proba



