load_fb15k
==============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_fb15k
