find_nearest_neighbours
============================================

.. currentmodule:: ampligraph.discovery

.. autofunction:: find_nearest_neighbours
