RandomNormal
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: RandomNormal

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RandomNormal.__init__
   
   .. automethod:: RandomNormal.__init__
   
   
