create_mappings
=====================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: create_mappings
