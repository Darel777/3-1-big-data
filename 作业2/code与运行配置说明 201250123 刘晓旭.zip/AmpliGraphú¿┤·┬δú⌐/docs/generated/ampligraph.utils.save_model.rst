save_model
===========================

.. currentmodule:: ampligraph.utils

.. autofunction:: save_model
