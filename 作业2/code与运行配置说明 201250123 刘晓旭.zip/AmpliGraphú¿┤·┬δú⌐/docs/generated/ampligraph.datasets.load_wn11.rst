load_wn11
=============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_wn11
