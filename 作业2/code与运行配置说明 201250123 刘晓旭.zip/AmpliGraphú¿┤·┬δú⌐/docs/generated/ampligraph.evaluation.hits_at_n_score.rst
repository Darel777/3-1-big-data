hits_at_n_score
=====================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: hits_at_n_score
