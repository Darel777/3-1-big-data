AdamOptimizer
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: AdamOptimizer

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AdamOptimizer.__init__
      ~AdamOptimizer.minimize
      ~AdamOptimizer.update_feed_dict
   
   .. automethod:: AdamOptimizer.__init__
   .. automethod:: AdamOptimizer.minimize
   .. automethod:: AdamOptimizer.update_feed_dict
   
   
