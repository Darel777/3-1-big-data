load_ppi5k
==============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_ppi5k
