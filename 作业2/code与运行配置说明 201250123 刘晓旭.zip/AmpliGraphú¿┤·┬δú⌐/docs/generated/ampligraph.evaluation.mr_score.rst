mr_score
==============================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: mr_score
