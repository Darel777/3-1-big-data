query_topn
===============================

.. currentmodule:: ampligraph.discovery

.. autofunction:: query_topn
