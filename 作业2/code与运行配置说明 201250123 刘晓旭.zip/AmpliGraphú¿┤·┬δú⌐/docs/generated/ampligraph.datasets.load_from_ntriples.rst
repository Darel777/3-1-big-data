load_from_ntriples
======================================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_from_ntriples
