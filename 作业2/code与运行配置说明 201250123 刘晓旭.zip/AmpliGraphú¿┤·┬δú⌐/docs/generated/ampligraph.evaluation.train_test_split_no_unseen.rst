train_test_split_no_unseen
================================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: train_test_split_no_unseen
