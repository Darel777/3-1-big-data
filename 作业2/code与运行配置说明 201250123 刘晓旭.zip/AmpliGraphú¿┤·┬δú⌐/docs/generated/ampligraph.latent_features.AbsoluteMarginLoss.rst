AbsoluteMarginLoss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: AbsoluteMarginLoss

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~AbsoluteMarginLoss.__init__
   
   .. automethod:: AbsoluteMarginLoss.__init__
   
   
