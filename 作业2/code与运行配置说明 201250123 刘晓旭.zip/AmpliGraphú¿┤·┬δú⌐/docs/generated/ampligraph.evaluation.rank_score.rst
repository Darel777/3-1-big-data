rank_score
================================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: rank_score
