Constant
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: Constant

   
   
   


   

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Constant.__init__
   
   .. automethod:: Constant.__init__
   