discover_facts
===================================

.. currentmodule:: ampligraph.discovery

.. autofunction:: discover_facts
