HolE
===============================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: HolE


   
   .. rubric:: Methods

   .. autosummary::
   
      ~HolE.__init__
      ~HolE.fit
      ~HolE.get_embeddings
      ~HolE.get_hyperparameter_dict
      ~HolE.predict
      ~HolE.calibrate
      ~HolE.predict_proba

   .. automethod:: HolE.__init__
   .. automethod:: HolE.fit
   .. automethod:: HolE.get_embeddings
   .. automethod:: HolE.get_hyperparameter_dict
   .. automethod:: HolE.predict
   .. automethod:: HolE.calibrate
   .. automethod:: HolE.predict_proba



