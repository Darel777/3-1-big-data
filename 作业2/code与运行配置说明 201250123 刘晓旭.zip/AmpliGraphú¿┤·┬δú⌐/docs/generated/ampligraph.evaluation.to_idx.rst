to_idx
============================

.. currentmodule:: ampligraph.evaluation

.. autofunction:: to_idx
