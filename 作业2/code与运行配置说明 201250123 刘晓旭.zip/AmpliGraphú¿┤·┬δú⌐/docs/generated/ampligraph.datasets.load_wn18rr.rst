load_wn18rr
===============================

.. currentmodule:: ampligraph.datasets

.. autofunction:: load_wn18rr
