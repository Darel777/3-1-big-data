BCELoss
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: BCELoss

   .. rubric:: Methods

   .. autosummary::
   
      ~BCELoss.__init__

   .. automethod:: BCELoss.__init__

   


