ComplEx
==================================

.. currentmodule:: ampligraph.latent_features

.. autoclass:: ComplEx


   
   .. rubric:: Methods

   .. autosummary::
   
      ~ComplEx.__init__
      ~ComplEx.fit
      ~ComplEx.get_embeddings
      ~ComplEx.get_hyperparameter_dict
      ~ComplEx.predict
      ~ComplEx.calibrate
      ~ComplEx.predict_proba

   .. automethod:: ComplEx.__init__
   .. automethod:: ComplEx.fit
   .. automethod:: ComplEx.get_embeddings
   .. automethod:: ComplEx.get_hyperparameter_dict
   .. automethod:: ComplEx.predict
   .. automethod:: ComplEx.calibrate
   .. automethod:: ComplEx.predict_proba



