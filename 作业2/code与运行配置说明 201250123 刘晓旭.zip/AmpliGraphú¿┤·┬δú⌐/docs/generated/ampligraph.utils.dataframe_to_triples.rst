dataframe_to_triples
=====================================

.. currentmodule:: ampligraph.utils

.. autofunction:: dataframe_to_triples
