Discovery
==========
.. currentmodule:: ampligraph.discovery

.. automodule:: ampligraph.discovery


.. autosummary::
    :toctree: generated
    :template: function.rst

    discover_facts
    find_clusters
    find_duplicates
    query_topn
    find_nearest_neighbours




