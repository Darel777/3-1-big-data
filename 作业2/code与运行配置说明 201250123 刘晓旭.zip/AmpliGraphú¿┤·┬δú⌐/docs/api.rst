API
===

AmpliGraph includes the following submodules:


.. toctree::
    :maxdepth: 1

    ampligraph.datasets
    ampligraph.latent_features
    ampligraph.evaluation
    ampligraph.discovery
    ampligraph.utils
